#include <stdio.h>
#include <assert.h>
#include <stdint.h>
#include "memory.h"

// Define MEMORY_SIZE if not defined in memory.h
#ifndef MEMORY_SIZE
#define MEMORY_SIZE 1024
#endif

void test_memory_initialization() {
    // All memory should be initialized to 0 by default
    for (uint32_t i = 0; i < MEMORY_SIZE; i++) {
        assert(read_memory(i) == 0);
    }
}

void test_memory_read_write() {
    write_memory(100, 42); // Write value 42 to address 100
    uint32_t value = read_memory(100); // Read value from address 100
    assert(value == 42); // Verify that the value read is the same as the value written
}

void run_memory_tests() {
    test_memory_initialization();
    test_memory_read_write();
    printf("All memory tests passed!\n");
}

int main() {
    run_memory_tests();
    return 0;
}