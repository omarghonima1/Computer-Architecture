#include <stdio.h>
#include <assert.h>
#include "cpu.h"
#include "registers.h"
#include "memory.h"

void test_cpu_initialization() {
    initialize_registers();
    assert(get_PC() == 0);
    for (int i = 0; i < 32; i++) {
        assert(get_register(i) == 0);
    }
}

void test_run_program_halt() {
    // Write HALT instruction at address 0
    write_memory(0, 0xFFFFFFFF);
    set_PC(0);
    run_program();
    // After HALT, PC should be 1
    assert(get_PC() == 1);
}

int main() {
    test_cpu_initialization();
    test_run_program_halt();
    printf("All CPU tests passed!\n");
    return 0;
}