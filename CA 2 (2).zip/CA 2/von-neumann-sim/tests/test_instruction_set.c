#include <stdio.h>
#include <assert.h>
#include "cpu.h"
#include "registers.h"
#include "memory.h"
#include "instruction.h"

// Helper to encode an R-format instruction
uint32_t encode_r(uint32_t opcode, uint32_t rd, uint32_t rs, uint32_t rt, uint32_t shamt) {
    return (opcode << 28) | (rd << 23) | (rs << 18) | (rt << 13) | (shamt & 0x1FFF);
}

// Helper to encode an I-format instruction
uint32_t encode_i(uint32_t opcode, uint32_t rs, uint32_t rt, uint32_t imm) {
    return (opcode << 28) | (rs << 23) | (rt << 18) | (imm & 0x1FFF);
}

// Helper to encode a J-format instruction
uint32_t encode_j(uint32_t opcode, uint32_t address) {
    return (opcode << 28) | (address & 0x0FFFFFFF);
}

void test_add() {
    initialize_registers();
    set_register(2, 5);
    set_register(3, 10);
    uint32_t instr = encode_r(0, 1, 2, 3, 0); // ADD R1 R2 R3
    instructionIdentifier(instr);
    assert(get_register(1) == 15);
    printf("ADD passed\n");
}

void test_sub() {
    initialize_registers();
    set_register(2, 10);
    set_register(3, 5);
    uint32_t instr = encode_r(1, 1, 2, 3, 0); // SUB R1 R2 R3
    instructionIdentifier(instr);
    assert(get_register(1) == 5);
    printf("SUB passed\n");
}

void test_muli() {
    initialize_registers();
    set_register(2, 3);
    uint32_t instr = encode_i(2, 2, 1, 4); // MULI R1 R2 4
    instructionIdentifier(instr);
    assert(get_register(1) == 12);
    printf("MULI passed\n");
}

void test_addi() {
    initialize_registers();
    set_register(2, 7);
    uint32_t instr = encode_i(3, 2, 1, 8); // ADDI R1 R2 8
    instructionIdentifier(instr);
    assert(get_register(1) == 15);
    printf("ADDI passed\n");
}

void test_bne() {
    initialize_registers();
    set_register(2, 5);
    set_register(1, 7);
    set_PC(10);
    uint32_t instr = encode_i(4, 2, 1, 3); // BNE R2 R1 3
    instructionIdentifier(instr);
    assert(get_PC() == 13); // PC should be incremented by 3
    printf("BNE passed\n");
}

void test_andi() {
    initialize_registers();
    set_register(2, 0xF0F);
    uint32_t instr = encode_i(5, 2, 1, 0x0FF); // ANDI R1 R2 0x0FF
    instructionIdentifier(instr);
    assert(get_register(1) == (0xF0F & 0x0FF));
    printf("ANDI passed\n");
}

void test_ori() {
    initialize_registers();
    set_register(2, 0xF0F);
    uint32_t instr = encode_i(6, 2, 1, 0x0FF); // ORI R1 R2 0x0FF
    instructionIdentifier(instr);
    assert(get_register(1) == (0xF0F | 0x0FF));
    printf("ORI passed\n");
}

void test_j() {
    initialize_registers();
    set_PC(5);
    uint32_t instr = encode_j(7, 1234); // J 1234
    instructionIdentifier(instr);
    assert(get_PC() == 1234);
    printf("J passed\n");
}

void test_sll() {
    initialize_registers();
    set_register(2, 1);
    uint32_t instr = encode_r(8, 1, 2, 0, 3); // SLL R1 R2 3 (R3 is 0)
    instructionIdentifier(instr);
    assert(get_register(1) == 8); // 1 << 3 == 8
    printf("SLL passed\n");
}

void test_srl() {
    initialize_registers();
    set_register(2, 16);
    uint32_t instr = encode_r(9, 1, 2, 0, 2); // SRL R1 R2 2 (R3 is 0)
    instructionIdentifier(instr);
    assert(get_register(1) == 4); // 16 >> 2 == 4
    printf("SRL passed\n");
}

void test_lw() {
    initialize_registers();
    set_register(2, 10);
    write_memory(13, 12345); // MEM[10+3] = 12345
    uint32_t instr = encode_i(10, 2, 1, 3); // LW R1 R2 3
    instructionIdentifier(instr);
    assert(get_register(1) == 12345);
    printf("LW passed\n");
}

void test_sw() {
    initialize_registers();
    set_register(2, 20);
    set_register(1, 0xBEEF);
    uint32_t instr = encode_i(11, 2, 1, 5); // SW R1 R2 5
    instructionIdentifier(instr);
    assert(read_memory(25) == 0xBEEF); // MEM[20+5] == 0xBEEF
    printf("SW passed\n");
}

int main() {
    test_add();
    test_sub();
    test_muli();
    test_addi();
    test_bne();
    test_andi();
    test_ori();
    test_j();
    test_sll();
    test_srl();
    test_lw();
    test_sw();
    printf("All instruction set tests passed.\n");
    return 0;
}