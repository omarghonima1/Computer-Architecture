# README for the Include Directory

This directory contains header files that define the interfaces for the various components of the Von Neumann architecture simulation. 

## Structure

- **cpu.h**: Contains declarations for CPU functions and structures.
- **memory.h**: Contains declarations for memory management functions and structures.
- **instruction_set.h**: Contains declarations for the instruction set functions and structures.
- **utils.h**: Contains declarations for utility functions used throughout the project.

## Usage

To use the functions and structures defined in this directory, include the relevant header files in your source files. For example:

```c
#include "cpu.h"
#include "memory.h"
#include "instruction_set.h"
#include "utils.h"
```

Ensure that the implementation files are compiled and linked correctly to utilize the functionality provided by these headers.