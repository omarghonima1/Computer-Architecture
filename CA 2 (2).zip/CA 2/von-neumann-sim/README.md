# Von Neumann Architecture Simulation

This project simulates a fictional processor design based on the Von Neumann architecture. It provides a framework for understanding how a CPU interacts with memory and executes instructions.

## Project Structure

- **src/**: Contains the source code for the simulation.
  - **main.c**: Entry point of the simulation.
  - **cpu.c**: Implementation of CPU functions.
  - **cpu.h**: Header file for CPU functions and structures.
  - **memory.c**: Implementation of memory management functions.
  - **memory.h**: Header file for memory functions and structures.
  - **instruction_set.c**: Implementation of the CPU's instruction set.
  - **instruction_set.h**: Header file for instruction set functions and structures.
  - **utils.c**: Utility functions for logging and error handling.
  - **utils.h**: Header file for utility functions.

- **include/**: Contains additional header files and documentation.
  - **README.md**: Documentation and guidelines for using the include directory.

- **tests/**: Contains unit tests for various components of the simulation.
  - **test_cpu.c**: Unit tests for CPU functions.
  - **test_memory.c**: Unit tests for memory functions.
  - **test_instruction_set.c**: Unit tests for instruction set functions.

- **Makefile**: Build instructions for compiling the source files and linking them into an executable.

## Setup Instructions

1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Run `make` to build the project.
4. Execute the simulation using `./von-neumann-sim`.

## Usage

The simulation initializes the CPU and memory, loads a set of instructions, and begins execution. You can modify the instruction set and memory contents to explore different scenarios.

## About Von Neumann Architecture

The Von Neumann architecture is a computer architecture model that describes a system where the CPU, memory, and input/output devices are interconnected. It uses a single memory space for both instructions and data, allowing for flexibility in program execution. This simulation aims to provide insights into how such a system operates.