#include "instruction.h"
#include "registers.h"
#include "memory.h"
#include <stdio.h>
#include <stdint.h>

// Helper: sign-extend an 18-bit immediate to 32 bits
static int32_t sign_extend_18(uint32_t val) {
    if (val & (1 << 17)) // if sign bit is set
        return (int32_t)(val | 0xFFFFC00); // extend with 1s
    else
        return (int32_t)val;
}

void instructionIdentifier(uint32_t instr) {
    uint32_t opcode = (instr >> 28) & 0xF;
    RFormat r;
    IFormat i;
    JFormat j;

    switch (opcode) {
        case 0: // ADD (R)
            r = decodeRFormat(instr);
            set_register(r.r1, get_register(r.r2) + get_register(r.r3));
            break;
        case 1: // SUB (R)
            r = decodeRFormat(instr);
            set_register(r.r1, get_register(r.r2) - get_register(r.r3));
            break;
        case 2: // MULI (I)
            i = decodeIFormat(instr);
            set_register(i.r1, get_register(i.r2) * sign_extend_18(i.immediate));
            break;
        case 3: // ADDI (I)
            i = decodeIFormat(instr);
            set_register(i.r1, get_register(i.r2) + sign_extend_18(i.immediate));
            break;
        case 4: // BNE (I)
            i = decodeIFormat(instr);
            if (get_register(i.r1) != get_register(i.r2))
                set_PC(get_PC() + sign_extend_18(i.immediate));
            break;
        case 5: // ANDI (I)
            i = decodeIFormat(instr);
            set_register(i.r1, get_register(i.r2) & (i.immediate & 0x3FFFF));
            break;
        case 6: // ORI (I)
            i = decodeIFormat(instr);
            set_register(i.r1, get_register(i.r2) | (i.immediate & 0x3FFFF));
            break;
        case 7: // J (J)
            j = decodeJFormat(instr);
            set_PC(j.address);
            break;
        case 8: // SLL (R)
            r = decodeRFormat(instr);
            set_register(r.r1, get_register(r.r2) << r.shamt);
            break;
        case 9: // SRL (R)
            r = decodeRFormat(instr);
            set_register(r.r1, get_register(r.r2) >> r.shamt);
            break;
        case 10: // LW (I)
            i = decodeIFormat(instr);
            set_register(i.r1, read_memory(get_register(i.r2) + sign_extend_18(i.immediate)));
            break;
        case 11: // SW (I)
            i = decodeIFormat(instr);
            write_memory(get_register(i.r2) + sign_extend_18(i.immediate), get_register(i.r1));
            break;
        default:
            break;
    }
}

// R-Format: [opcode:4][R1:5][R2:5][R3:5][SHAMT:13]
RFormat decodeRFormat(uint32_t instr) {
    RFormat r;
    r.r1    = (instr >> 23) & 0x1F;
    r.r2    = (instr >> 18) & 0x1F;
    r.r3    = (instr >> 13) & 0x1F;
    r.shamt = instr & 0x1FFF;
    return r;
}

// I-Format: [opcode:4][R1:5][R2:5][IMM:18]
IFormat decodeIFormat(uint32_t instr) {
    IFormat i;
    i.r1        = (instr >> 23) & 0x1F;
    i.r2        = (instr >> 18) & 0x1F;
    i.immediate = instr & 0x3FFFF;
    return i;
}

// J-Format: [opcode:4][ADDRESS:28]
JFormat decodeJFormat(uint32_t instr) {
    JFormat j;
    j.address = instr & 0x0FFFFFFF;
    return j;
}