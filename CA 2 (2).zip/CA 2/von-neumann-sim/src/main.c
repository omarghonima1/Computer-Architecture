#include <stdio.h>
#include "cpu.h"
#include "memory.h"
#include "registers.h"

int main() {
    initialize_registers(); // <-- Move it here!
    // Load program into memory
    load_program("program.txt"); // Change filename if needed

    // Run the program (fetch-decode-execute loop)
    run_program();

    // Dump register and memory state for debugging/grading
    dump_registers("registers_dump.txt");
    dump_memory("memory_dump.txt");

    return 0;
}