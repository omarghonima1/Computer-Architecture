#ifndef CPU_H
#define CPU_H

#include <stdint.h>

// Main function to run the fetch-decode-execute loop
void run_program(void);

// Declare this function to fix the error:
void decode_and_execute(uint32_t instruction);

#endif