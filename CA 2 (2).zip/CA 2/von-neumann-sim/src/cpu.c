#include "cpu.h"
#include "memory.h"
#include "registers.h"
#include "instruction.h"
#include <stdbool.h>
#include <stdio.h>

typedef struct {
    uint32_t pc;
    uint32_t instruction;
    bool valid;
} PipelineStage;

void run_program(void) {
    uint32_t clock_cycle = 1;
    PipelineStage IF = {0, 0, false};
    PipelineStage ID = {0, 0, false};
    PipelineStage EX = {0, 0, false};
    PipelineStage MEM = {0, 0, false};
    PipelineStage WB = {0, 0, false};

    uint32_t reg_before[32];
    uint32_t mem_before[MEMORY_SIZE];

    set_PC(0);
    IF.valid = true;

    bool fetch_allowed = true; // alternates each cycle

    while (IF.valid || ID.valid || EX.valid || MEM.valid || WB.valid) {
        printf("Clock Cycle: %u\n", clock_cycle);

        // Save register and memory state before execution for change detection
        for (int i = 0; i < 32; i++) reg_before[i] = get_register(i);
        for (uint32_t i = 0; i < MEMORY_SIZE; i++) mem_before[i] = read_memory(i);

        // Advance pipeline stages (WB <- MEM <- EX <- ID <- IF)
        WB = MEM;
        MEM = EX;
        EX = ID;
        ID = IF;

        // IF and MEM cannot be active in the same cycle
        if (fetch_allowed) {
            // IF stage
            if (get_PC() < 1024) {
                IF.pc = get_PC();
                IF.instruction = read_memory(IF.pc);
                IF.valid = (IF.instruction != 0xFFFFFFFF && IF.pc < 1024);
                set_PC(get_PC() + 1);
            } else {
                IF.valid = false;
            }
        } else {
            IF.valid = false; // No fetch this cycle
        }

        // Print pipeline stages
        printf("IF: ");
        if (IF.valid) printf("PC = %u, Instruction = 0x%08X\n", IF.pc, IF.instruction);
        else printf("No instruction\n");
        printf("ID: ");
        if (ID.valid) printf("PC = %u, Instruction = 0x%08X\n", ID.pc, ID.instruction);
        else printf("No instruction\n");
        printf("EX: ");
        if (EX.valid) printf("PC = %u, Instruction = 0x%08X\n", EX.pc, EX.instruction);
        else printf("No instruction\n");
        printf("MEM: ");
        if (MEM.valid) printf("PC = %u, Instruction = 0x%08X\n", MEM.pc, MEM.instruction);
        else printf("No instruction\n");
        printf("WB: ");
        if (WB.valid) printf("PC = %u, Instruction = 0x%08X\n", WB.pc, WB.instruction);
        else printf("No instruction\n");

        // Only do memory access in MEM stage
        if (!fetch_allowed && MEM.valid) {
            // For loads/stores, do memory access here
            // You may need to split instructionIdentifier into EX/MEM/WB for full accuracy
            // For now, call instructionIdentifier here for MEM stage
            instructionIdentifier(MEM.instruction);
        }
        // Only do register write in WB stage
        if (WB.valid && fetch_allowed) {
            // For instructions that write to registers, do it here
            // For now, call instructionIdentifier here for WB stage for non-memory instructions
            instructionIdentifier(WB.instruction);
        }

        // Print register updates
        for (int i = 0; i < 32; i++) {
            if (get_register(i) != reg_before[i]) {
                printf("Register R%d updated: %d -> %d\n", i, reg_before[i], get_register(i));
            }
        }
        // Print memory updates
        for (uint32_t i = 0; i < MEMORY_SIZE; i++) {
            uint32_t after = read_memory(i);
            if (after != mem_before[i]) {
                printf("Memory MEM[%u] updated: %u -> %u\n", i, mem_before[i], after);
            }
        }

        printf("--------------------------------------------------\n");

        // Stop if HALT was in WB or MEM stage
        if ((WB.valid && WB.instruction == 0xFFFFFFFF) ||
            (!fetch_allowed && MEM.valid && MEM.instruction == 0xFFFFFFFF))
            break;

        fetch_allowed = !fetch_allowed; // alternate IF/MEM
        clock_cycle++;
    }

    // Print final register and memory state
    printf("\nFinal Register State:\n");
    for (int i = 0; i < 32; i++) {
        printf("R%d: %d\n", i, get_register(i));
    }
    printf("PC: %u\n", get_PC());

    printf("\nFinal Memory State (non-zero values):\n");
    for (uint32_t i = 0; i < MEMORY_SIZE; i++) {
        uint32_t val = read_memory(i);
        if (val != 0)
            printf("MEM[%u]: %u\n", i, val);
    }
}
