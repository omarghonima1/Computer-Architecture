#ifndef INSTRUCTION_H
#define INSTRUCTION_H

#include <stdint.h>

// R-Format: [opcode:4][R1:5][R2:5][R3:5][SHAMT:13]
typedef struct {
    uint32_t r1;     // Destination register
    uint32_t r2;     // Source register 1
    uint32_t r3;     // Source register 2
    uint32_t shamt;  // Shift amount
} RFormat;

// I-Format: [opcode:4][R1:5][R2:5][IMM:18]
typedef struct {
    uint32_t r1;        // Destination register
    uint32_t r2;        // Source register
    uint32_t immediate; // 18-bit immediate
} IFormat;

// J-Format: [opcode:4][ADDRESS:28]
typedef struct {
    uint32_t address;   // 28-bit address
} JFormat;

void instructionIdentifier(uint32_t instr);
RFormat decodeRFormat(uint32_t instr);
IFormat decodeIFormat(uint32_t instr);
JFormat decodeJFormat(uint32_t instr);

#endif
