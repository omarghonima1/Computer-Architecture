#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>
#define MEMORY_SIZE 2048

void write_memory(uint32_t address, uint32_t value);
uint32_t read_memory(uint32_t address);
void load_program(const char* filename);
void dump_memory(const char* filename);

#endif
