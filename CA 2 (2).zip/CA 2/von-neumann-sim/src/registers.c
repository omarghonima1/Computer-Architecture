#include "registers.h"
#include <stdint.h>
#include <stdio.h>

static int32_t registers[32] = {0};
static uint32_t PC = 0;

void initialize_registers(void) {
    for (int i = 0; i < 32; i++) registers[i] = 0;
    PC = 0;
}

int32_t get_register(uint32_t idx) {
    if (idx < 32)
        return registers[idx];
    return 0;
}

void set_register(uint32_t idx, int32_t value) {
    if (idx != 0 && idx < 32) // R0 is always zero
        registers[idx] = value;
}

void set_PC(uint32_t value) {
    PC = value;
}

uint32_t get_PC(void) {
    return PC;
}

void dump_registers(const char* filename) {
    FILE* f = fopen(filename, "w");
    if (!f) return;
    for (int i = 0; i < 32; i++)
        fprintf(f, "R%d: %d\n", i, registers[i]);
    fprintf(f, "PC: %u\n", PC);
    fclose(f);
}