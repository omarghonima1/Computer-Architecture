#ifndef REGISTERS_H
#define REGISTERS_H

#include <stdint.h>

void initialize_registers(void);
int32_t get_register(uint32_t idx);
void set_register(uint32_t idx, int32_t value);
void set_PC(uint32_t value);
uint32_t get_PC(void);
void dump_registers(const char* filename);

#endif
