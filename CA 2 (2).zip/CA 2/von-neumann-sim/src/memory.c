#include "memory.h"
#include <stdio.h>
#include <stdint.h>

static uint32_t memory[MEMORY_SIZE] = {0};

void write_memory(uint32_t address, uint32_t value) {
    if (address < MEMORY_SIZE)
        memory[address] = value;
}

uint32_t read_memory(uint32_t address) {
    if (address < MEMORY_SIZE)
        return memory[address];
    return 0;
}

void load_program(const char* filename) {
    FILE* f = fopen(filename, "r");
    if (!f) {
        printf("Error opening program file.\n");
        return;
    }
    uint32_t addr = 0, instr;
    while (fscanf(f, "%x", &instr) == 1 && addr < 1024) {
        memory[addr++] = instr;
        printf("Loaded instruction 0x%08X at MEM[%u]\n", instr, addr-1);
    }
    fclose(f);
}

void dump_memory(const char* filename) {
    FILE* f = fopen(filename, "w");
    if (!f) return;
    for (uint32_t i = 0; i < MEMORY_SIZE; i++) {
        if (memory[i] != 0)
            fprintf(f, "MEM[%u]: %u\n", i, memory[i]);
    }
    fclose(f);
}